# Crisis Dataset + ML Collapse Prediction

## Can we predict market collapses?

**Short answer:** Only weakly. Stress features rank future severe-drawdown months better than chance (ROC-AUC often ~0.6–0.75 depending on target/split), and PR-AUC beats the prevalence baseline, but **precision at operational recall stays modest**. Many alerts are false alarms. Treat models as risk *thermometers*, not collapse timers.

## Setup (leakage-aware)
- Features at month t: VIX, GPR, EPU, NFCI, credit spreads, STLFSI, oil, sentiment, curve, stress composites and lags — **not** the contemporaneous Collapsed flag used as a free feature for the same-month label.
- Forward targets:
  - y_dd_6m: path min return over next 6 months ≤ −10%
  - y_dd_12m: path min return over next 12 months ≤ −15%
  - y_crash_12m: point 12-month return ≤ −15%
- Train ≤ 2015-12; test ≥ 2016-01. Also expanding walk-forward by year.

## Metrics chosen
| Metric | Why |
|--------|-----|
| **PR-AUC** | Primary under class imbalance (rare severe drawdowns) |
| **ROC-AUC** | Ranking quality (can look better than practical utility) |
| **Precision / Recall / F1** | Operating-point tradeoff for warnings |
| **Brier** | Probability calibration |

For rare collapses, maximizing recall alone floods you with false alarms. A balanced operating point keeps precision meaningfully above prevalence while capturing a useful fraction of events.

## Models
- Balanced logistic regression (L2, standardized features)
- Shallow balanced random forest (pure NumPy implementation)

## Key files
- crisis_core_monthly.csv — features, Collapsed, forward targets, ML probabilities
- ml_collapse_results.csv — metrics by model/target
- ml_walkforward_yearly.csv — year-by-year expanding evaluation
- ml_pr_curve_dd6m_lr.csv, ml_roc_curve_dd6m_lr.csv — curve points
- ml_feature_importance_lr.csv — logistic coefficients
- crisis_features_dataset.zip — full package

Not investment advice.
